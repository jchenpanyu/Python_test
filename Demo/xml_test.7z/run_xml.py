import lxml.etree as ET
root = ET.parse("xml_test.xml")
A_element = root.findall("./A")
for element in A_element:
    for sub_el in element:
        if(sub_el.tag == "street"):
            sub_el.tail = "\n    "
    append_el = ET.Element("append_el")
    append_el.text = "2"
    append_el.tail = "\n  "
    element.append(append_el)
root.write('test_out.xml', pretty_print=True, xml_declaration=True, encoding='utf-8')